import java.util.*;
import java.io.*;

public class ATM implements Serializable {
    private String accountNumber;
    private int balance;
    public String name;

    public ATM(String name, String accountNumber, int balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.name = name;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "\n\nAccount Name: "+name+ "\nAccount Number: "+accountNumber+"\nBalance: "+balance;
    }


}